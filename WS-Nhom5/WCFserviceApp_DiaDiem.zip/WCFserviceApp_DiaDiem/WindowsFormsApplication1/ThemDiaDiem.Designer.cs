﻿namespace WindowsFormsApplication1
{
    partial class ThemDiaDiem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.cbb_LinhVuc = new System.Windows.Forms.ComboBox();
            this.linhVucBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.diaDiem_WebserviceDataSet = new WindowsFormsApplication1.DiaDiem_WebserviceDataSet();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.cbb_PhanLoai = new System.Windows.Forms.ComboBox();
            this.txt_TenDiaDiem = new System.Windows.Forms.TextBox();
            this.txt_DiaChi = new System.Windows.Forms.TextBox();
            this.txt_Kinhdo = new System.Windows.Forms.TextBox();
            this.txt_LienLac = new System.Windows.Forms.TextBox();
            this.txt_ViDo = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_DuongDan = new System.Windows.Forms.TextBox();
            this.btn_Openfile = new System.Windows.Forms.Button();
            this.btn_Them = new System.Windows.Forms.Button();
            this.btn_Thoat = new System.Windows.Forms.Button();
            this.linhVucTableAdapter = new WindowsFormsApplication1.DiaDiem_WebserviceDataSetTableAdapters.LinhVucTableAdapter();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_TenAvatar = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.linhVucBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.diaDiem_WebserviceDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // cbb_LinhVuc
            // 
            this.cbb_LinhVuc.DataSource = this.linhVucBindingSource;
            this.cbb_LinhVuc.DisplayMember = "LinhVuc";
            this.cbb_LinhVuc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_LinhVuc.FormattingEnabled = true;
            this.cbb_LinhVuc.Location = new System.Drawing.Point(100, 11);
            this.cbb_LinhVuc.Name = "cbb_LinhVuc";
            this.cbb_LinhVuc.Size = new System.Drawing.Size(165, 21);
            this.cbb_LinhVuc.TabIndex = 0;
            this.cbb_LinhVuc.ValueMember = "ID";
            this.cbb_LinhVuc.SelectedIndexChanged += new System.EventHandler(this.cbb_LinhVuc_SelectedIndexChanged);
            // 
            // linhVucBindingSource
            // 
            this.linhVucBindingSource.DataMember = "LinhVuc";
            this.linhVucBindingSource.DataSource = this.diaDiem_WebserviceDataSet;
            // 
            // diaDiem_WebserviceDataSet
            // 
            this.diaDiem_WebserviceDataSet.DataSetName = "DiaDiem_WebserviceDataSet";
            this.diaDiem_WebserviceDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Lĩnh vực: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(271, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Phân loại: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Tên địa điểm: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(271, 76);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Địa chỉ: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(271, 110);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Liên lạc:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 80);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "Kinh độ: ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 107);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "Vĩ độ:";
            // 
            // cbb_PhanLoai
            // 
            this.cbb_PhanLoai.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbb_PhanLoai.FormattingEnabled = true;
            this.cbb_PhanLoai.Location = new System.Drawing.Point(324, 11);
            this.cbb_PhanLoai.Name = "cbb_PhanLoai";
            this.cbb_PhanLoai.Size = new System.Drawing.Size(194, 21);
            this.cbb_PhanLoai.TabIndex = 9;
            // 
            // txt_TenDiaDiem
            // 
            this.txt_TenDiaDiem.Location = new System.Drawing.Point(100, 43);
            this.txt_TenDiaDiem.Name = "txt_TenDiaDiem";
            this.txt_TenDiaDiem.Size = new System.Drawing.Size(418, 20);
            this.txt_TenDiaDiem.TabIndex = 10;
            // 
            // txt_DiaChi
            // 
            this.txt_DiaChi.Location = new System.Drawing.Point(324, 73);
            this.txt_DiaChi.Name = "txt_DiaChi";
            this.txt_DiaChi.Size = new System.Drawing.Size(194, 20);
            this.txt_DiaChi.TabIndex = 11;
            // 
            // txt_Kinhdo
            // 
            this.txt_Kinhdo.Location = new System.Drawing.Point(100, 73);
            this.txt_Kinhdo.Name = "txt_Kinhdo";
            this.txt_Kinhdo.Size = new System.Drawing.Size(165, 20);
            this.txt_Kinhdo.TabIndex = 12;
            // 
            // txt_LienLac
            // 
            this.txt_LienLac.Location = new System.Drawing.Point(324, 103);
            this.txt_LienLac.Name = "txt_LienLac";
            this.txt_LienLac.Size = new System.Drawing.Size(194, 20);
            this.txt_LienLac.TabIndex = 13;
            // 
            // txt_ViDo
            // 
            this.txt_ViDo.Location = new System.Drawing.Point(100, 107);
            this.txt_ViDo.Name = "txt_ViDo";
            this.txt_ViDo.Size = new System.Drawing.Size(165, 20);
            this.txt_ViDo.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 137);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Tên ảnh ";
            // 
            // txt_DuongDan
            // 
            this.txt_DuongDan.Location = new System.Drawing.Point(100, 134);
            this.txt_DuongDan.Name = "txt_DuongDan";
            this.txt_DuongDan.Size = new System.Drawing.Size(329, 20);
            this.txt_DuongDan.TabIndex = 15;
            this.txt_DuongDan.Visible = false;
            // 
            // btn_Openfile
            // 
            this.btn_Openfile.Location = new System.Drawing.Point(443, 132);
            this.btn_Openfile.Name = "btn_Openfile";
            this.btn_Openfile.Size = new System.Drawing.Size(75, 23);
            this.btn_Openfile.TabIndex = 16;
            this.btn_Openfile.Text = "Upload ảnh";
            this.btn_Openfile.UseVisualStyleBackColor = true;
            this.btn_Openfile.Click += new System.EventHandler(this.btn_Openfile_Click);
            // 
            // btn_Them
            // 
            this.btn_Them.Location = new System.Drawing.Point(100, 169);
            this.btn_Them.Name = "btn_Them";
            this.btn_Them.Size = new System.Drawing.Size(104, 23);
            this.btn_Them.TabIndex = 17;
            this.btn_Them.Text = "Thêm Thông Tin";
            this.btn_Them.UseVisualStyleBackColor = true;
            this.btn_Them.Click += new System.EventHandler(this.btn_Them_Click);
            // 
            // btn_Thoat
            // 
            this.btn_Thoat.Location = new System.Drawing.Point(237, 169);
            this.btn_Thoat.Name = "btn_Thoat";
            this.btn_Thoat.Size = new System.Drawing.Size(75, 23);
            this.btn_Thoat.TabIndex = 18;
            this.btn_Thoat.Text = "Thoát";
            this.btn_Thoat.UseVisualStyleBackColor = true;
            this.btn_Thoat.Click += new System.EventHandler(this.btn_Thoat_Click);
            // 
            // linhVucTableAdapter
            // 
            this.linhVucTableAdapter.ClearBeforeFill = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(361, 172);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 17);
            this.label9.TabIndex = 19;
            this.label9.Text = "Tình Trạng";
            // 
            // txt_TenAvatar
            // 
            this.txt_TenAvatar.Location = new System.Drawing.Point(100, 133);
            this.txt_TenAvatar.Name = "txt_TenAvatar";
            this.txt_TenAvatar.Size = new System.Drawing.Size(329, 20);
            this.txt_TenAvatar.TabIndex = 20;
            // 
            // ThemDiaDiem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 204);
            this.Controls.Add(this.txt_TenAvatar);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btn_Thoat);
            this.Controls.Add(this.btn_Them);
            this.Controls.Add(this.btn_Openfile);
            this.Controls.Add(this.txt_DuongDan);
            this.Controls.Add(this.txt_ViDo);
            this.Controls.Add(this.txt_LienLac);
            this.Controls.Add(this.txt_Kinhdo);
            this.Controls.Add(this.txt_DiaChi);
            this.Controls.Add(this.txt_TenDiaDiem);
            this.Controls.Add(this.cbb_PhanLoai);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbb_LinhVuc);
            this.Name = "ThemDiaDiem";
            this.Text = "ThemDiaDiem";
            this.Load += new System.EventHandler(this.ThemDiaDiem_Load);
            ((System.ComponentModel.ISupportInitialize)(this.linhVucBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.diaDiem_WebserviceDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbb_LinhVuc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cbb_PhanLoai;
        private System.Windows.Forms.TextBox txt_TenDiaDiem;
        private System.Windows.Forms.TextBox txt_DiaChi;
        private System.Windows.Forms.TextBox txt_Kinhdo;
        private System.Windows.Forms.TextBox txt_LienLac;
        private System.Windows.Forms.TextBox txt_ViDo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_DuongDan;
        private System.Windows.Forms.Button btn_Openfile;
        private System.Windows.Forms.Button btn_Them;
        private System.Windows.Forms.Button btn_Thoat;
        private DiaDiem_WebserviceDataSet diaDiem_WebserviceDataSet;
        private System.Windows.Forms.BindingSource linhVucBindingSource;
        private DiaDiem_WebserviceDataSetTableAdapters.LinhVucTableAdapter linhVucTableAdapter;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_TenAvatar;
    }
}