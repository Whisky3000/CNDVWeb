﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//Goi service
//using WindowsFormsApplication1.ServiceReference1;
//using System.ServiceModel;
//using WindowsFormsApplication1.ServiceReference2;



namespace WindowsFormsApplication1
{
    public partial class Formmain : Form
    {
        public Formmain()
        {
            InitializeComponent();
        }
        //Service_diadiemClient serviceclient = new Service_diadiemClient();

        private void DangnhapToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Dangnhap dn = new Dangnhap();
            dn.Show();
        }

        private void ThoatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
        ////TTDDClient TTDD = new TTDDClient();
        //private void button1_Click(object sender, EventArgs e)
        //{
        //    //label1.Text = TTDD.NhanThongtin(1, 1, "Khach san", "ks", "sd", "df", "gf", "cv", "bv", "nb");
        //    //label1.Text = serviceclient.ThemThongTin(1, "Khach san thai an", "a", "b", "c", "d", "e", "f", "g", "h", 0);

            
        //    try
        //    {
        //        //Thêm Mã phân loại sai là 0, thêm đúng (1-9)
        //        label1.Text = serviceclient.ThemThongTin(1, "Khach san thai a 11n", "aa", "bb", "cb", "dd", "ee", "ff", "gg", "hh", 1);
        //    }
        //    catch (FaultException<CustomFaultMsg> ex)
        //    {
        //        MessageBox.Show(ex.Message, "error");
        //    } 
        //}

        //private void Get_Click(object sender, EventArgs e)
        //{
        //    dataGridView1.DataSource = serviceclient.TaoBang("Select * From LinhVuc");
        //    dataGridView1.Show();
        //}

        
    }
}
