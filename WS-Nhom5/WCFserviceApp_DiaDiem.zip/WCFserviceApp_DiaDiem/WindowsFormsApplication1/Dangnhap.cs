﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

//Goi Service
using WindowsFormsApplication1.ServiceReference1;

namespace WindowsFormsApplication1
{
    public partial class Dangnhap : Form
    {
        public Dangnhap()
        {
            InitializeComponent();
        }
        ServiceClient svClient = new ServiceClient();
        private void Dangnhap_Load(object sender, EventArgs e)
        {

        }

        private void btn_Thoat_Click(object sender, EventArgs e)
        {
            Close();
        }
        
        private void btn_DangNhap_Click(object sender, EventArgs e)
        {
            Thongtindiadiem info = new Thongtindiadiem();
            if (svClient.Dangnhap(txt_User.Text, txt_Pass.Text) == 1)
            {
                info.Show();
                Close();
 
            }
            else
            {
                MessageBox.Show("Nhập đúng tên người dùng và mật khẩu! Xin cám ơn^^.");
            }

        }

       

       
    }
}
