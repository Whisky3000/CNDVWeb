﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace WindowsFormsApplication1
{
    class Cosodulieu
    {
        private static string StrKetnoi = @"Data Source=JOSEPH-PC\SQLEXPRESS;Initial Catalog=DiaDiem_Webservice; Integrated Security=True";
        public static SqlConnection CN;
        public string ChuoiKetnoi()
        {
            return StrKetnoi;
        }
        public void ThietlapKetnoi()
        {
            try
            {
                CN = new SqlConnection(StrKetnoi);
                CN.Open();

            }
            catch
            {

            }
        }
        public void HuyKetnoi()
        {
            CN.Close();
        }
        //Lấy dữ liệu từ bảng;
        public DataTable TaoBang(string sql)
        {
            ThietlapKetnoi();
            SqlDataAdapter Adapter = new SqlDataAdapter(sql, CN);
            DataTable DTable = new DataTable();
            Adapter.Fill(DTable);
            Adapter.Update(DTable);
            return DTable;

        }
    }
}
