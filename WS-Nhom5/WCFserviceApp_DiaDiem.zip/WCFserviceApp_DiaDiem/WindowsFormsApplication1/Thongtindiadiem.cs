﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


//Goi Service
using WindowsFormsApplication1.ServiceReference1;

namespace WindowsFormsApplication1
{
    public partial class Thongtindiadiem : Form
    {
        public Thongtindiadiem()
        {
            InitializeComponent();
        }
        ServiceClient svClient = new ServiceClient();
        private void button1_Click(object sender, EventArgs e)
        {
            
            Close();
        }

        private void Thongtindiadiem_Load(object sender, EventArgs e)
        {

            //Datagridview.DataSource = svClient.TaoBang("Select * From DiaDiem");
            //Datagridview.Show();
        }

        private void btn_Them_Click(object sender, EventArgs e)
        {
            ThemDiaDiem fthem = new ThemDiaDiem();
            fthem.Show();
            Close();
        }
    }
}
