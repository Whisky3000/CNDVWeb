﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Web.UI.MobileControls;
using System.Drawing;
using System.IO;
using System.Collections;


namespace WCFserviceApp_DiaDiem
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    public class Service1 : IService
    {

        //Hàm lưu hình ảnh
        public void LuuAnh(string s, string tenanh)
        {
            string rua = "D:\\Baitap\\WebService\\WCFserviceApp_DiaDiem\\Images\\" + tenanh + ".jpg";
            System.Drawing.Image b = Base64ToImage(s);

            b.Save(rua, System.Drawing.Imaging.ImageFormat.Png);
        }
        //Chuyển ảnh từ string sang Imsge
        public System.Drawing.Image Base64ToImage(string base64String)
        {

            byte[] imageBytes = Convert.FromBase64String(base64String);
            MemoryStream ms = new MemoryStream(imageBytes, 0, imageBytes.Length);


            ms.Write(imageBytes, 0, imageBytes.Length);
            System.Drawing.Image image = System.Drawing.Image.FromStream(ms, true);
            return image;
        }

        //Thêm dữ liệu vào Khách Sạn
        public string ThemThongTin(int Maphanloai, string TenDiaDiem, string Lng, string Lat, string Diachi, string Lienlac, string Avatar, string TenAvatar)
        {
            try
            {
                //Mở kết nối tham chiếu từ lớp kết nối dữ liệu
                ThietlapKetnoi();

                //-----------Nhập liệu---------------//
                SqlCommand cmd = new SqlCommand(@"INSERT INTO DiaDiem  VALUES (@ID_PhanLoai,@TenDiaDiem,@Lng,@Lat,@DiaChi,@LienLac,@Avatar,@HinhAnh,@Rating,@SoNguoiRating)", CN);

                cmd.Parameters.AddWithValue("@ID_PhanLoai", Maphanloai);
                cmd.Parameters.AddWithValue("@TenDiaDiem", TenDiaDiem);
                cmd.Parameters.AddWithValue("@Lng", Lng);
                cmd.Parameters.AddWithValue("@Lat", Lat);
                cmd.Parameters.AddWithValue("@DiaChi", Diachi);
                cmd.Parameters.AddWithValue("@LienLac", Lienlac);
                cmd.Parameters.AddWithValue("@Avatar", TenAvatar);
                cmd.Parameters.AddWithValue("@HinhAnh", ""); 
                cmd.Parameters.AddWithValue("@Rating", 0.00);
                cmd.Parameters.AddWithValue("@SoNguoiRating", 0);
                
                //Luu Anh
                LuuAnh(Avatar,TenAvatar);
                //-----------------------------------//
                //-----------Đưa vào CSDL------------//
                cmd.ExecuteNonQuery();
                //-----------------------------------//
                //Hủy kết nối CSDL
                HuyKetnoi();
                return "Thành công";
            }
            catch 
            {
                return "Không thành công!";
            }
        }

        //Chấm điểm Rating
        //public string Rating(int ID_diadiem, float Rating)
        //{
        //    Double diemso=Convert.ToDouble( Rating.Trim());
        //    if (1 <= diemso && diemso <= 5)
        //    {
        //        ThietlapKetnoi();
        //        //THay doi trang thai
        //        SqlDataAdapter adap = new SqlDataAdapter("Select * from DiaDiem", CN);
        //        DataSet data = new DataSet();
        //        adap.Fill(data);

        //        //Kiểm tra trạng thái
        //        Double ratig;
        //        foreach (DataRow row in data.Tables[0].Rows)
        //        {
        //            ratig=Convert.ToDouble(row[8]);//Chuyển rating từ string Double
        //            if (ratig < diemso)
        //            {
        //                SqlCommand command = new SqlCommand("UPDATE [DiaDiem] SET [Rating] = '" + diemso.ToString() + "' WHERE ID = " + ID_diadiem, CN);
        //                command.ExecuteNonQuery();
        //            }
        //            else Rating = "Chấm hơn số điểm hiện tại^^";
        //        }
        //        HuyKetnoi();
        //        return Rating;
        //    }
        //    else return "Điểm chỉ từ 1 đến 5.^^";

 
        //}

        //DangNhap(String Username, String Password) 
        public int Dangnhap(string User, string Pass)
        {
            SqlConnection conn = new SqlConnection(StrKetnoi);
            string strSQL = "SELECT COUNT(*) FROM DangNhap WHERE Username = '" + User + "' AND Password = '" + Pass + "'";
            SqlCommand objCmd = new SqlCommand(strSQL, conn);
            int iResults;
            try
            {
                conn.Open();
                iResults = Convert.ToInt32(objCmd.ExecuteScalar().ToString());
            }
            catch
            {
                conn.Close();
                return -1;
            }
            finally
            {
                conn.Close();
            }

            if (iResults == 1)
                //Login thành công
                return 1;
            else
                //login thất bại
                return -2;

 
        }

        //XÓa thông tin ko cần thiết
        public int XoaThongTinDiaDiem(int ID_DiaDiem)
        {
            string SQL = @"DELETE FROM DiaDiem WHERE ID = '"+ID_DiaDiem+"'";
            try
            {
                ExcuteNonQuery(SQL);
                return 1;

            }
            catch
            {
                return 0;
 
            }
 
        }

        //Thay đổi thông tin
        //public int ThayDoiThongTinDiaDiem(int ID_DiaDiem,string ID_PhanLoai,string Ten,string GPS,string Diachi,string LienLac,string Avatar,string HinhAnh,string Rating,int Trangthai)
        //{
        //    string SQL = @"UPDATE DiaDiem SET ID_PhanLoai =  '"+ID_PhanLoai+"' ,Ten = '"+Ten+"',GPS = '"+GPS+"',Diachi ='"+Diachi+"',LienLac = '"+LienLac+"',Avatar ='"+Avatar+"',HinhAnh = '"+HinhAnh+"',Rating = '"+Rating+"',Trangthai = '"+Trangthai+"' WHERE ID='"+ID_DiaDiem+"'";
        //    try
        //    {
        //        ExcuteNonQuery(SQL);
        //        return 1;

        //    }
        //    catch
        //    {
        //        return 0;

        //    }
 
        //}

        //Báo cáo sai
        //public int BaoCaoSai(int ID)
        //{
        //    string SQL = @"";
        //}

        //-----------//Phần kết nối cơ sở dữ liệu//------------//

        private static string StrKetnoi = @"Data Source=JOSEPH-PC\SQLEXPRESS;Initial Catalog=DiaDiem_Webservice; Integrated Security=True";
        public static SqlConnection CN;
        public string ChuoiKetnoi()
        {
            return StrKetnoi;
        }
        public void ThietlapKetnoi()
        {
            try
            {
                CN = new SqlConnection(StrKetnoi);
                CN.Open();

            }
            catch
            {

            }
        }
        public void HuyKetnoi()
        {
            CN.Close();
        }
        //Lấy dữ liệu từ bảng;
        public DataTable TaoBang()
        {
            ThietlapKetnoi();
            SqlDataAdapter Adapter = new SqlDataAdapter("Select * From DiaDiem", CN);
            DataTable DTable = new DataTable();
            Adapter.Fill(DTable);
            return DTable;

        }
        //Ham thuc hien lenh executenonquery
        public void ExcuteNonQuery(string sql)
        {
            //Ket noi Database
            ThietlapKetnoi();
            //Thực hiện insert
            SqlCommand cmd = new SqlCommand(sql, CN);
            cmd.ExecuteNonQuery();
            //Hủy kết nối Database
            HuyKetnoi();
            cmd.Dispose();
        }
        //
        public ArrayList DuLieuDiaDiem()
        {
            ThietlapKetnoi();

            string sqlState = "SELECT * FROM DiaDiem";
            SqlCommand cmd = new SqlCommand(sqlState, CN);
            SqlDataReader reader = cmd.ExecuteReader();
            ArrayList results = new ArrayList();

            while (reader.Read())
            {
                results.Add(reader.GetValue(1));
                results.Add(reader.GetValue(2));
            }
            reader.Close();
            HuyKetnoi();
            return results;
        }

        //
        public DataSet DuLieuPhanLoai()
        {
            ThietlapKetnoi();
            SqlDataAdapter Adapter = new SqlDataAdapter("SELECT ID FROM PhanLoai", CN);
            DataSet DTaset = new DataSet();
            Adapter.Fill(DTaset);
            HuyKetnoi();
            return DTaset;
 
        }


    }
    
}
