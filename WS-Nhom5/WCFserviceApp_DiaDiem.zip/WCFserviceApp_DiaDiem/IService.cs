﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Data;
using System.Collections;

namespace WCFserviceApp_DiaDiem
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService
    {

         //TODO: Add your service operations here
        [OperationContract]
        string ChuoiKetnoi();
        [OperationContract]
        void ThietlapKetnoi();
        [OperationContract]
        void HuyKetnoi();
        [OperationContract]
        DataTable TaoBang();

        [OperationContract]
        ArrayList DuLieuDiaDiem();

        [OperationContract]
        DataSet DuLieuPhanLoai();

        [OperationContract]
        void ExcuteNonQuery(string sql);

        //Thêm thông tin địa điểm   
        [OperationContract]
        string ThemThongTin(int Maphanloai, string TenDiaDiem, string Lng, string Lat, string Diachi, string Lienlac, string Avatar, string TenAvatar);
        //
        //[OperationContract]
        //string Rating(int ID_diadiem,string Rating);
        //Đăng nhập
        [OperationContract]
        int Dangnhap(string User, string Pass);
        //Xóa thông tin địa điểm
        [OperationContract]
        int XoaThongTinDiaDiem(int ID_DiaDiem);
        //Báo cáo sai
        //[OperationContract]
        //int ThayDoiThongTinDiaDiem(int ID_DiaDiem, string ID_PhanLoai, string Ten, string GPS, string Diachi, string LienLac, string Avatar, string HinhAnh, string Rating, int Trangthai);
    }


    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    [DataContract]
    public class CompositeType
    {
        bool boolValue = true;
        string stringValue = "Hello ";

        [DataMember]
        public bool BoolValue
        {
            get { return boolValue; }
            set { boolValue = value; }
        }

        [DataMember]
        public string StringValue
        {
            get { return stringValue; }
            set { stringValue = value; }
        }
    }

    [DataContract]
    public class Thongtindiadiem
    {
        [DataMember]
        public string Tenlinhvuc;
        [DataMember]
        public int Malinhvuc;
        [DataMember]
        public string Tenphanloai;
        [DataMember]
        public int Maphanloai;
        [DataMember]
        public string Ten;
        [DataMember]
        public string GPS;
        [DataMember]
        public string Diachi;
        [DataMember]
        public string Quan;
        [DataMember]
        public string Thanhpho;
        [DataMember]
        public string Lienlac;
        [DataMember]
        public string Thongtin;
        [DataMember]
        public string Avatar;
        [DataMember]
        public int Trangthai;

    }
}
